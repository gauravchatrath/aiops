import os

os.system('./edit_cluster.sh 3')
